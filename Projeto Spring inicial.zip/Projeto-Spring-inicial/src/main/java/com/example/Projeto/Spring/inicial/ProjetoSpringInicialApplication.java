package com.example.Projeto.Spring.inicial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoSpringInicialApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoSpringInicialApplication.class, args);
	}

}
