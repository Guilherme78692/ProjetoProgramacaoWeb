package com.example.Projeto.Spring.inicial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoSpringInicialApplicationTests {

	@Test
	void contextLoads() {
	}

}
